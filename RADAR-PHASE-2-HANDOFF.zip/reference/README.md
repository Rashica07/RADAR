# reference/

Material that exists only in the session that produced Phase 2 (uploads and scratch space). Kept here so the handoff is standalone. **None of it is in the git repository** unless you commit it.

## brand-sheets/
The three images you supplied in chat (all 1536×1024, AI-generated raster sheets):

| File | Contents |
|---|---|
| `brand-sheet-1-v1-logo.png` | first logo sheet (11 sections). **Superseded** by sheet 2 |
| `brand-sheet-2-v2-logo.png` | **current logo**: primary logo, symbol, wordmark, symbol+wordmark, monochrome, iOS/Android/favicon icons, palette, type |
| `brand-sheet-3-glitch.png` | **glitched logo** and glitched icons (the source of the speed-smear look) |

## artifact-screenshots/
11 of 26 screenshots of the Phase 01 artifact (`https://claude.ai/artifact/Js5gigTTofFCDwYCoWtWKW`, version `1795423913-ab52`), 393×852 CSS px at DPR 1, dark theme, Chromium, taken on 2026-11-23. `*-full.png` are full-page captures. The greeting/date text on Discover reflects the capture date.

Caveats: the artifact uses a MemoryRouter, so a local copy was patched to read the route from `location.hash` (see `tools/PATCH_ROUTER.md`). Not included: `queue.png` (a duplicate of `player.png`, the click failed), `context.png` (not inspected), `nope*.png` (just Discover), and the viewport-only duplicates of the full-page shots.

## tools/
Playwright scripts used for the screenshots and the logo fit. They live only in scratch space in the original session. `node` + `playwright` required; set `NODE_PATH=$(npm root -g)`.

| Script | Use |
|---|---|
| `shoot2.js <site-dir> <out-dir>` | screenshots every route of the patched local copy |
| `shoot3.js <site-dir> <out-dir>` | player + search-results states (its queue and context-menu selectors did not work) |
| `render.js <svg> <png> <w> <h>` | renders an SVG to PNG with Chromium (this produced the app-icon PNGs) |
| `iou.js <out-dir>` | rasterises `docs/brand/radar-symbol.svg` and `radar-wordmark.svg` for the IoU measurement (the numpy comparison itself was an inline snippet, described in `DESIGN_SPEC.md` §4.4) |
