# Patching the artifact for screenshots

The artifact renders with `MemoryRouter`, so every URL opens Discover. To screenshot a route, copy the artifact's published files to a local folder and, in `assets/index-BFXzLKka.js`, replace the **single** occurrence of

    uo=Bt;

with

    uo=(p)=>_.createElement(Bt,{...p,initialEntries:[location.hash.slice(1)||"/"]});

(`Bt` is the minified MemoryRouter in this specific build; the identifiers will differ in any other build.) Then serve the folder with any static server that falls back to `index.html`, and open `http://localhost:8765/#/trending`, `#/track/ottobre`, etc. `shoot2.js` does this with a tiny built-in server.
