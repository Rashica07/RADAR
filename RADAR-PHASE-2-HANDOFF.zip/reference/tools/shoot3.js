const { chromium } = require('playwright');
const http = require('http'); const fs = require('fs'); const path = require('path');
const root = process.argv[2], out = process.argv[3];
const types = {'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.woff2':'font/woff2','.woff':'font/woff'};
const srv = http.createServer((req,res)=>{ let p = decodeURIComponent(req.url.split('?')[0]); if (p==='/'||!fs.existsSync(path.join(root,p))) p='/index.html'; res.setHeader('Content-Type', types[path.extname(p)]||'application/octet-stream'); fs.createReadStream(path.join(root,p)).pipe(res);}).listen(8765, async ()=>{
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport:{width:393,height:852}, deviceScaleFactor:1, isMobile:true, hasTouch:true });
  const pg = await ctx.newPage();
  pg.on('pageerror', e => console.log('PAGEERR', e.message));
  await pg.goto('http://localhost:8765/#/'); await pg.waitForTimeout(1500);
  // dump mini player DOM classes
  console.log((await pg.evaluate(()=>[...document.querySelectorAll('[class*=mini]')].map(e=>e.className).slice(0,15).join('\n'))));
  const mini = await pg.$('.mini, [class*="mini"]'); 
  await pg.click('.mini__meta, .mini__info, .mini__body, .mini').catch(e=>console.log('clickfail', e.message));
  await pg.waitForTimeout(1200); await pg.screenshot({ path: `${out}/player.png` });
  console.log((await pg.evaluate(()=>[...document.querySelectorAll('[class*=player] button, [class*=xp] button')].map(e=>e.getAttribute('aria-label')).join(' | '))));
  await pg.click('button[aria-label*="queue" i], button[aria-label*="Queue"]').catch(e=>console.log('qfail',e.message));
  await pg.waitForTimeout(1000); await pg.screenshot({ path: `${out}/queue.png` });
  await pg.goto('http://localhost:8765/#/library'); await pg.reload(); await pg.waitForTimeout(1500);
  await pg.click('button[aria-label^="More options"], button[aria-label*="options" i]').catch(e=>console.log('ctxfail',e.message));
  await pg.waitForTimeout(800); await pg.screenshot({ path: `${out}/context.png` });
  await pg.goto('http://localhost:8765/#/search'); await pg.reload(); await pg.waitForTimeout(1200);
  await pg.fill('input', 'ott'); await pg.waitForTimeout(1200); await pg.screenshot({ path: `${out}/search-results.png`, fullPage:true });
  await b.close(); srv.close();
});
