const { chromium } = require('playwright'); const fs=require('fs');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1000,height:300}});
for (const [name,file,w,h] of [['sym','docs/brand/radar-symbol.svg',361,207],['word','docs/brand/radar-wordmark.svg',859,118]]) {
  await p.setViewportSize({width:w,height:h});
  await p.setContent(`<body style="margin:0;background:transparent">${fs.readFileSync(file,'utf8').replace('<svg ','<svg style="display:block" ')}</body>`);
  await p.screenshot({path:`${process.argv[2]}/iou-${name}.png`,omitBackground:true});
}
await b.close(); })();
