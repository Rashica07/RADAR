const { chromium } = require('playwright');
const http = require('http'); const fs = require('fs'); const path = require('path');
const root = process.argv[2], out = process.argv[3];
const types = {'.js':'text/javascript','.css':'text/css','.html':'text/html','.svg':'image/svg+xml','.woff2':'font/woff2','.woff':'font/woff'};
const srv = http.createServer((req,res)=>{ let p = decodeURIComponent(req.url.split('?')[0]); if (p==='/'||!fs.existsSync(path.join(root,p))) p='/index.html'; res.setHeader('Content-Type', types[path.extname(p)]||'application/octet-stream'); fs.createReadStream(path.join(root,p)).pipe(res);}).listen(8765, async ()=>{
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport:{width:393,height:852}, deviceScaleFactor:1, isMobile:true, hasTouch:true });
  const pg = await ctx.newPage();
  pg.on('pageerror', e => console.log('PAGEERR', e.message));
  for (const r of ['/trending','/search','/library','/settings','/track/ottobre','/artist/noor','/playlist/italy-rising','/album/velluto-ep','/art','/nope']) {
    await pg.goto('http://localhost:8765/#'+r); await pg.reload(); await pg.waitForTimeout(2200);
    const n = r.slice(1).replace('/','-');
    await pg.screenshot({ path: `${out}/${n}.png` });
    await pg.screenshot({ path: `${out}/${n}-full.png`, fullPage: true });
  }
  await b.close(); srv.close();
});
